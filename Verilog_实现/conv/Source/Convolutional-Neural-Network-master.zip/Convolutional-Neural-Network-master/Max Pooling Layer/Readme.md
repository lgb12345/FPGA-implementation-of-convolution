Max Pooling Layer is used for finding maximum in the 2X2 submatrix.

This folder contains the top level module and the testbench for implementation of the Max Pooling Layer.

Module is tested by providing inputs from test bench file.
