
This folder contains imlpementation of the first layer of convolution of Image/pattern with Laplacian Filter. 

Conv1.v is the top level file which calls the sub modules of the convolution implemenation. The module is tested by providing inputs from the Conv1_tb.v testbench.
