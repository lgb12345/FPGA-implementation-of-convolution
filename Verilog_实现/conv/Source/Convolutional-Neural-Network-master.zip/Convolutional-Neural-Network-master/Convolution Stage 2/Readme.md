
Convolution Stage 2 - convolution of convolved image with convolved pattern

This folder contains code files only for the second layer of convolution of outputs obtained from the first layer of convolution.

Conv2_Full.v is the top level file which calls the sub modules of the convolution implemenation. The module is tested by providing inputs from the Conv2_Full_tb.v testbench.
